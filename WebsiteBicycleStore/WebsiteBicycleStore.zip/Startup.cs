﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WebsiteBicycleStore.Startup))]
namespace WebsiteBicycleStore
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            //ConfigureAuth(app);
        }
    }
}
